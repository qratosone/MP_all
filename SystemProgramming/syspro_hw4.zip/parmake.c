/** @file parmake.c */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>

/**
 * Entry point to parmake.
 */
int main(int argc, char **argv)
{
	return 0; 
}
