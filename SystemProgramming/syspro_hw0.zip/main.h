#ifndef __MAIN_H
#define __MAIN_H

void one(const int a, const int b);
void two(const int grade);
void three();
void four(const float value);
void five(const int x, const int y);
float * six(const int *x);
void seven(int a, const int b);
void eight();
void nine();
void ten(int *x);
void eleven();
void twelve();
void thirteen();
void fourteen(const char *s);
void fifteen(const int value);
char * sixteen();
void seventeen(const int d);
void eighteen(int k);
long int clear_bits(long int value, long int flag);

#endif // __MAIN_H